#include <avr/interrupt.h>
#include <stdint.h>

void timer_init(void);
